# AC Power Supply

[3d Mean Well LRS-350-36 cover](https://www.thingiverse.com/thing:2302140)
