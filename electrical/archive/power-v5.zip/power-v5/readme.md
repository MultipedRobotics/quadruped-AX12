# Power Distribution Board

## Schematic

[pdf schematic](power.pdf)

## Board

![](pics/top.png)

![](pics/bottom.png)
